<?php $__env->startSection('title', 'Anasayfa'); ?>
    
<?php $__env->startSection('content'); ?>

 <!-- Start Banner One -->
 <section class="banner-one">
    <div class="banner-one__inner">
        <div class="slider-bg-slide"
            data-options='{ "delay": 5000, "slides": [ 
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {"src": "<?php echo e($slide->src); ?>" }<?php echo e($loop->last ? '' : ','); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             ], "transition": "fade", "animation": "kenburns", "timer": false, "align": "top" }'>
        </div>
        <div class="slider-bg-slide-overly"></div>
        <div class="container">
            <div class="banner-one__content text-center">
                <div class="title">
                    <h2>Mükemmel Mekanı Bul</h2>
                </div>
                <div class="text">
                    <p>Şehirindeki mekanları listele, sana en uygun olanı bul.</p>
                </div>


                <!--Start Banner One Tab Box-->
                <div class="banner-one__tab-box">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="banner-one__tab tabs-box">
                                
                                <div class="banner-one__tab-content-item">
                                    <div class="banner-one__tab-content-places">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="banner-one__tab-content-places-form">
                                                    <form action="assets/inc/sendemail.php"
                                                        class="comment-one__form contact-form-validated"
                                                        novalidate="novalidate">

                                                        <ul>
                                                            <li>
                                                                <div class="comment-form__input-box">
                                                                    <div class="icon">
                                                                        <span
                                                                            class="fas fa-keyboard"></span>
                                                                    </div>
                                                                    <input type="text" placeholder="Hangi mekanlara bakıyorsunuz?" name="name">
                                                                </div>
                                                            </li>

                                                            <li>
                                                                <div class="comment-form__input-box">
                                                                    <div class="icon">
                                                                        <span class="icon-pin"></span>
                                                                    </div>
                                                                    <input type="text"
                                                                        placeholder="Konum"
                                                                        value="İstanbul"
                                                                        name="name">
                                                                </div>
                                                            </li>

                                                            <li>
                                                                <div
                                                                    class="comment-form__input-box clearfix">
                                                                    <div class="icon">
                                                                        <span class="icon-list"></span>
                                                                    </div>
                                                                    <div class="select-box">
                                                                        <select class="selectmenu wide">
                                                                            <option value="0" selected="selected"> Tüm Kategoriler</option>
                                                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </li>

                                                            <li>
                                                                <button
                                                                    class="thm-btn comment-form__btn"
                                                                    type="submit"
                                                                    data-loading-text="Please wait...">Ara
                                                                    <span class="icon-search"></span>
                                                                </button>
                                                            </li>
                                                        </ul>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!--End Banner One Tab Box Tab Box-->


                <div class="banner-one__categories">
                    <div class="title">
                        <h4>Sadece etrafa mı bakıyorsun? Kategoriye göre hızlı aramayı kullanın:</h4>
                    </div>
                    <ul class="banner-one__categories-list">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="banner-one__categories-list-item">
                            <div class="inner">
                                <div class="icon">
                                    <span class="<?php echo e($category->icon); ?>"></span>
                                </div>
                                <p><a href="#"><?php echo e($category->short_name); ?></a></p>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Banner One -->

<!--Start Place One-->
<section class="place-one">
    <div class="container">
        <div class="sec-title text-center">
            <h2 class="sec-title__title">Vitrindeki Mekanlar</h2>
            <p class="sec-title__text">Editörlerimizin sizin için seçtiği mükemmel mekanlara göz atın.</p>
        </div>
        <div class="row">
            <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <!--Start Place One Single-->
            <div class="col-xl-4 col-lg-6 col-md-6">
                <div class="place-one__single">
                    <div class="place-one__single-img">
                        <div class="place-one__single-img-inner">
                            
                            <img src="<?php echo e($place->cover); ?>" alt="" />
                        </div>
                        <div class="text-box">
                            <span><?php echo e($place->MainCategory->name); ?></span>
                        </div>
                    </div>

                    <div class="place-one__single-content">
                        <div class="top-content">
                            <h2><a href="/place/<?php echo e($place->slug); ?>"><?php echo e($place->title); ?></a></h2>
                            
                           
                                
                                
                                <div class="d-flex flex-wrap">
                                    <?php $__currentLoopData = $place->Features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge bg-primary me-2 mb-2 pe-4"><span class="p-2 <?php echo e($feature->Feature->icon); ?>"></span> <?php echo e($feature->Feature->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                            
                        </div>
                      
                    
                    
                        <div class="bottom-content d-flex justify-content-between">
                            <ul class="review-box">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <?php if($place->Stars->count() > 0): ?>
                                        <?php if($i <= round($place->Stars->sum('star') / $place->Stars->count())): ?>
                                            <li><span class="fas fa-star"></span></li>
                                        <?php else: ?>
                                        <li><span class="far fa-star"></span></li>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <li><span class="far fa-star"></span></li>
                                    <?php endif; ?>
                                   
                                <?php endfor; ?>
                                <li class="text-dark">
                                    (<?php echo e($place->Stars->count() > 0 ?  round($place->Stars->sum('star') / $place->Stars->count()) : '0'); ?>)
                                </li>
                            </ul>
                            

                            <span>
                                <i class="fas fa-comments"></i> <?php echo e($place->Comments->count()); ?>

                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Place One Single-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!--End Place One-->


<!--Start Features One-->
<section class="features-one">
    <div class="container">
        <div class="sec-title text-center">
            <h2 class="sec-title__title">Nasıl Kullanılır?</h2>
            <p class="sec-title__text">4 adımda uygunmekan.com nasıl kullanılır?</p>
        </div>
        <div class="row">
            <!--Start Features One Single-->
            <div class="col-xl-3 col-lg-3 col-md-6 wow fadeInLeft" data-wow-delay="0ms"
                data-wow-duration="1000ms">
                <div class="features-one__single text-center">
                    <div class="features-one__single-icon">
                        <span class="fas fa-user-plus"></span>
                    </div>
                    <div class="features-one__single-title">
                        <h2><a href="#">Hesap Oluştur</a></h2>
                    </div>
                </div>
            </div>
            <!--End Features One Single-->

            <!--Start Features One Single-->
            <div class="col-xl-3 col-lg-3 col-md-6 wow fadeInLeft" data-wow-delay="100ms"
                data-wow-duration="1000ms">
                <div class="features-one__single text-center">
                    <div class="features-one__single-icon">
                        <span class="fas fa-search"></span>
                    </div>
                    <div class="features-one__single-title">
                        <h2><a href="#">Mekanları Ara</a></h2>
                    </div>
                </div>
            </div>
            <!--End Features One Single-->

            <!--Start Features One Single-->
            <div class="col-xl-3 col-lg-3 col-md-6 wow fadeInRight" data-wow-delay="0ms"
                data-wow-duration="1000ms">
                <div class="features-one__single text-center">
                    <div class="features-one__single-icon">
                        <span class="icon-checklist"></span>
                    </div>
                    <div class="features-one__single-title">
                        <h2><a href="#">Uygun Olanı Bul</a></h2>
                    </div>
                </div>
            </div>
            <!--End Features One Single-->

            <!--Start Features One Single-->
            <div class="col-xl-3 col-lg-3 col-md-6 wow fadeInRight" data-wow-delay="100ms"
                data-wow-duration="1000ms">
                <div class="features-one__single text-center">
                    <div class="features-one__single-icon">
                        <span class="fas fa-share"></span>
                    </div>
                    <div class="features-one__single-title">
                        <h2><a href="#">Görüşlerini Paylaş </a></h2>
                    </div>
                </div>
            </div>
            <!--End Features One Single-->
        </div>
    </div>
</section>
<!--End Features One-->


<!--Start Video One-->
<section class="video-one">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="video-one__inner">
                    <div class="video-one__bg"
                        style="background-image: url(assets/images/backgrounds/3.png);"></div>
                    <div class="video-box">
                        <a href="https://www.youtube.com/watch?v=Get7rqXYrbQ" class="video-popup">
                            <div class="video-one__video-icon">
                                <span class="fa fa-play"></span>
                                <i class="ripple"></i>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End Video One-->


<!--Start Testimonial One-->
<section class="testimonial-one">
    <div class="testimonial-one__bg"
        style="background-image: url(assets/images/backgrounds/3.png);"></div>
    <div class="container">
        <div class="sec-title text-center">
            <h2 class="sec-title__title">Mekanlara Son Yorumlar</h2>
            <p class="sec-title__text">Mekanlarımıza gönderilen son yorumlar.</p>
        </div>
        <div class="row">
            <div class="col-xl-12">
                <div class="owl-carousel owl-theme thm-owl__carousel testimonial-one__carousel"
                    data-owl-options='{
                    "loop": true,
                    "autoplay": true,
                    "margin": 30,
                    "nav": false,
                    "dots": false,
                    "smartSpeed": 500,
                    "autoplayTimeout": 3000,
                    "navText": ["<span class=\"fa fa-angle-left\"></span>","<span class=\"fa fa-angle-right\"></span>"],
                    "responsive": {
                        "0": {
                            "items": 1
                        },
                        "768": {
                            "items": 2
                        },
                        "992": {
                            "items": 2
                        },
                        "1200": {
                            "items": 2
                        }
                        }
                    }'>

                    <!--Start Testimonial One Single-->
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="testimonial-one__single">
                            <div class="testimonial-one__single-quote-icon">
                                <span class="fa fa-quote-left"></span>
                            </div>
                            <div class="testimonial-one__single-top">
                                <div class="text-box">
                                    <h2><?php echo e($comment->User->name); ?></h2>
                                    <p><?php echo e($comment->Place->title); ?></p>
                                </div>
                            </div>
                            <div class="testimonial-one__single-text">
                                <p><?php echo e($comment->comment); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--End Testimonial One Single-->
                </div>
            </div>
        </div>
    </div>
</section>
<!--End Testimonial One-->


<!--Start Blog One-->
<section class="blog-one">
    <div class="container">
        <div class="sec-title text-center">
            <h2 class="sec-title__title">Blogumuzdan Yazılar</h2>
            <p class="sec-title__text">En son blog yazılarımıza göz atın.</p>
        </div>
        <div class="row">

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 col-lg-4 wow fadeInDown" data-wow-delay=".3s">
                    <div class="blog-one__single">
                        <div class="blog-one__single-img">
                            <img src="<?php echo e($post->cover); ?>" alt="" />
                        </div>

                        <div class="blog-one__single-content">
                            
                            <h2><a href="/blog/detail/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a>
                            </h2>
                            <div class="line"></div>
                            <div class="text">
                                <p><?php echo e(substr($post->detail, 0, 85).'...'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--Start Blog One Single-->
            
            <!--End Blog One Single-->


        </div>
    </div>
</section>
<!--End Blog One-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alihanozturk/Projects/uygun-mekan/resources/views/main/index.blade.php ENDPATH**/ ?>